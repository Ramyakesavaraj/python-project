from flask import Flask, request, flash, url_for, redirect, render_template
from flask_sqlalchemy import SQLAlchemy
app = Flask(__name__)
app.config['SQLALCHEMY_DATABASE_URI'] = 'postgresql://postgres:kgisl@localhost/knowledgesharing'
app.config['SECRET_KEY'] = "random string"
db = SQLAlchemy(app) 
@app.route('/a')
def log():
	return render_template("in.html")
@app.route('/b')
def feature():
	return render_template("first.html")
@app.route('/c')
def procees():
	return render_template("selection.html")
@app.route('/d')
def sel():
	return render_template("nextlevel.html")
@app.route('/e')
def lan():
	return render_template("main.html") 
@app.route('/f')
def deta():
	return render_template("details.html") 
@app.route('/user')
def user():
	return render_template("user.html",register=register.query.all())
@app.route('/language')
def language(): 
	return render_template("language.html",selec=selec.query.all())
@app.route('/other')
def other():
	return render_template("other.html",select=select.query.all())
@app.route('/last')
def last():
	return render_template("last.html",detail=detail.query.all())

 
class register(db.Model):
	id = db.Column('reg_id', db.Integer, primary_key = True)
	username = db.Column(db.String(100))
	emailsignup = db.Column(db.String(50))
	password = db.Column(db.String(200)) 
	passwordsignup_confirm = db.Column(db.String(10))
	def __init__(self, username, emailsignup, password, passwordsignup_confirm):
		self.username = username
		self.emailsignup = emailsignup
		self.password = password
		self.passwordsignup_confirm = passwordsignup_confirm
	@app.route('/in', methods = ['GET', 'POST'])
	def new():
		if request.method == 'POST':
				if not request.form['username'] or not request.form['emailsignup'] or not request.form['password'] or not request.form['passwordsignup_confirm']:
					flash('Please enter all the fields', 'error')
				else:
					reg = register(request.form['username'], request.form['emailsignup'], request.form['password'], request.form['passwordsignup_confirm'])
					db.session.add(reg)
					db.session.commit()
					flash('Record was successfully added')
					return redirect(url_for('feature'))
				return render_template('in.html')
@app.route('/log', methods=['POST','GET'])
def logi():
	if request.method=='GET':
		return render_template('in.html')
	username = request.form['username']
	password = request.form['password']
	reg =register.query.filter_by(username=username,password=password).first()
	if request.form['password'] == 'admin' and request.form['username'] == 'admin':
		return render_template("admin.html")
	if reg is None:
		return render_template("in.html")
	else:
		return render_template("first.html")

class select(db.Model):
	id = db.Column('reg_id', db.Integer, primary_key = True)
	other = db.Column(db.String(10))
	def __init__(self, other):
		self.other = other
	@app.route('/nextlevel', methods = ['GET', 'POST'])
	def next():
		if request.method == 'POST':
				if not request.form['other']:
					flash('Please enter all the fields', 'error')
				else:
					reg = select(request.form['other'])
					db.session.add(reg)
					db.session.commit()
					flash('Record was successfully added')
					return redirect(url_for('sel'))
		return render_template('selection.html')
class selec(db.Model):
	id = db.Column('reg_id', db.Integer, primary_key = True)
	language = db.Column(db.String(100))
	def __init__(self, language):
		self.language = language
	@app.route('/e', methods = ['GET', 'POST'])
	def mainn():
		if request.method == 'POST':
				if not request.form['language']:
					flash('Please enter all the fields', 'error')
				else:
					reg = selec(request.form['language'])
					db.session.add(reg)
					db.session.commit()
					flash('Record was successfully added')
					return redirect(url_for('lan'))
		return render_template('selection.html')
class detail(db.Model):
	id = db.Column('reg_id', db.Integer, primary_key = True)
	name = db.Column(db.String(100))
	board = db.Column(db.String(50))
	university = db.Column(db.String(200)) 
	city = db.Column(db.String(100))
	state = db.Column(db.String(100))
	def __init__(self, name, board, university, city, state):
		self.name = name
		self.board = board
		self.university = university
		self.city = city
		self.state = state
	@app.route('/details', methods = ['GET', 'POST'])
	def det():
		if request.method == 'POST':
				if not request.form['name'] or not request.form['board'] or not request.form['university'] or not request.form['city'] or not request.form['state']:
					flash('Please enter all the fields', 'error')
				else:
					reg = detail(request.form['name'], request.form['board'], request.form['university'], request.form['city'], request.form['state'])
					db.session.add(reg)
					db.session.commit()
					flash('Record was successfully added')
					return redirect(url_for('deta'))
		return render_template('nextlevel.html')
 
if __name__ == '__main__':
	db.create_all()
	app.run(debug = True) 

							    

