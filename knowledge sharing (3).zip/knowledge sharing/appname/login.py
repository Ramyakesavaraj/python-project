from flask import Flask, request, flash, url_for, redirect, render_template
from flask_sqlalchemy import SQLAlchemy
app = Flask(__name__)
app.config['SQLALCHEMY_DATABASE_URI'] = 'postgresql://postgres:kgisl@localhost/knowledgesharing'
app.config['SECRET_KEY'] = "random string"
db = SQLAlchemy(app) 
@app.route('/a')
def log():
	return render_template("in.html")
@app.route('/b')
def feature():
	return render_template("first.html")
@app.route('/c')
def procees():
	return render_template("index.html") 
class register(db.Model):
	id = db.Column('reg_id', db.Integer, primary_key = True)
	usernamesignup = db.Column(db.String(100))
	emailsignup = db.Column(db.String(50))
	passwordsignup = db.Column(db.String(200)) 
	passwordsignup_confirm = db.Column(db.String(10))
	def __init__(self, usernamesignup, emailsignup, passwordsignup, passwordsignup_confirm):
		self.usernamesignup = usernamesignup
		self.emailsignup = emailsignup
		self.passwordsignup = passwordsignup
		self.passwordsignup_confirm = passwordsignup_confirm
	@app.route('/first', methods = ['GET', 'POST'])
	def new():
		if request.method == 'POST':
				if not request.form['usernamesignup'] or not request.form['emailsignup'] or not request.form['passwordsignup'] or not request.form['passwordsignup_confirm']:
					flash('Please enter all the fields', 'error')
				else:
					reg = register(request.form['usernamesignup'], request.form['emailsignup'], request.form['passwordsignup'], request.form['passwordsignup_confirm'])
					db.session.add(reg)
					db.session.commit()
					flash('Record was successfully added')
					return redirect(url_for('feature'))
		return render_template('in.html')
if __name__ == '__main__':
	db.create_all()
	app.run(debug = True) 

							    

