from flask import Flask, render_template
app = Flask(__name__)

@app.route('/login')
def log():
   return render_template("index3.html")
   
@app.route('/first')
def feature():
   return render_template("first.html")

@app.route('/index')
def search():
   return render_template("index.html")


if __name__ == '__main__':
   app.run(debug = True)

